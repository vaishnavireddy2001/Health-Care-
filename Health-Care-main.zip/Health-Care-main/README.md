# Health care: Heart attack possibility app



![Image of App](https://github.com/update-ankur/Health-Care/blob/main/src/app.png)


